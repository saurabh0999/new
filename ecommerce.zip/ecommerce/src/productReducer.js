import { addItem } from "./actions";
import {productslist} from "./productslist"

const initialState = {
    products: productslist,
    cart: [],
    totalAmount:0,
    totalItem:0,
    isSignedIn: false
}
  
const productReducer = (state = initialState, action) => {
    switch (action.type) {
        case 'ADD_ITEM':
            console.log("action.payload = "+action.payload)
            const updatedAddedCart = state.cart.map((item) => {
                if (item.id != action.payload) {
                    return [...state.cart, action.payload];
                }
                return item;
            });
            return { ...state, cart: updatedCart };
        case 'REMOVE_ITEM':
            return {
                ...state,
                cart:state.cart.filter((item) => {
                    return item.id != action.payload; 
                })
            };
        case 'CLEAR_CART':
            return {
                ...state,
                cart:[]
            };    
        case 'INCREMENT':
            const updatedCart = state.cart.map((item) => {
                if (item.id === action.payload) {
                  return { ...item, amount: item.amount + 1 };
                }
                return item;
            });
            return { ...state, cart: updatedCart };
        case 'DECREMENT':
            const newUpdatedCart = state.cart.map((item) => {
                if (item.id === action.payload) {
                  return { ...item, amount: item.amount - 1 };
                }
                return item;
            });
            return { ...state, cart: newUpdatedCart };
        case 'GET_TOTAL': 
            let { totalItem, totalAmount } = state.cart.reduce(
                (accum, curVal) => {
                    let { price, amount } = curVal;
            
                    let updatedTotalAmount = price * amount;
                    accum.totalAmount += updatedTotalAmount;
            
                    accum.totalItem += amount;
                    return accum;
                },
                {
                    totalItem: 0,
                    totalAmount: 0,
                }
            );
            return { ...state, totalItem, totalAmount };  
        default: return state;
    }
    
}

export default productReducer;
import React from "react";
import { useSelector } from 'react-redux'
import { Link } from 'react-router-dom';
//import {productslist} from "./productslist"

export default function Offer() {
  const productslist = useSelector((state) => state.products)
  return (
    <div>
      <h2 className="title">Women Clothes</h2>
      <div className="row">
        {productslist.map((item)=>{
          return  (item.subcategory === "" && item.category === "women") ? 
            (<div className="col-4"  key={item.id}>
                <Link to={"/productdetails/"+item.id}>
                  <img src={"images/"+item.img} />
                  <h4>{item.title}</h4>
                  <div className="rating">
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                    <i className="far fa-star"></i>
                    <i className="far fa-star"></i>
                  </div>
                  <p>Price: ₹{item.price}.00</p>
                </Link> 
              </div>) : ''
          })
        }      
      </div>
    </div>
  );
}

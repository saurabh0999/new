import logo from './logo.svg';
import React from 'react';

function Test(props) {
  var listOfImages = [
      {image:'https://assets.bwbx.io/images/users/iqjWHBFdfxIU/iKUhOPgZrfhs/v1/1000x-1.jpg'},
      {image:'https://scontent.fdel3-1.fna.fbcdn.net/v/t1.6435-9/cp0/e15/q65/s320x320/37160947_229260147699446_8494929348476796928_n.jpg?_nc_cat=104&ccb=1-5&_nc_sid=dd9801&efg=eyJpIjoiYiJ9&_nc_ohc=yp_hy88tRnoAX_ZdMv1&tn=-j11txG4nE6H-47O&_nc_ht=scontent.fdel3-1.fna&oh=13035dc5d9bfd6d5016f58d43388e281&oe=614F8793'},
      {image:'https://d1nxzqpcg2bym0.cloudfront.net/google_play/com.topsmartapps.myapps.amzndeals/cbc921d6-4c91-11e8-8072-3d5c27b72c5f/128x128'}
    ]
  return (
    <div>
       <h2>my test component Image list</h2>
        {listOfImages.map((item, key)=>{
            console.log("item",item)
            return <div><img className="myimages" id={key} src={item.image} /><br/></div>
        })}
    </div>
  );
}

export default Test;

import React, {useEffect} from 'react';
import './style.css';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import Main from './main';
import store from './store'
import { Provider } from 'react-redux'

function App() {
  return (
    <Provider store={store} >
        <Main/>
    </Provider>
  );
}

export default App;

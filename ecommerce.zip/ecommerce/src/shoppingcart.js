import React  from "react";
import { useSelector, useDispatch } from 'react-redux'
import { increment, removeItem } from "./actions";

export default function Shoppingcart() {
    const cartlist = useSelector((state) => state.cart)
    console.log('cartlist', cartlist);
    const state = useSelector((state) => state)
    const dispatch = useDispatch()
    return(
        <div class="small-contain cart-page">
            <table>
                <tr>
                    <th>Product</th>
                    <th>Quantity</th>
                    <th>Subtotal</th>
                </tr>
                {
                    cartlist.map((item)=>{ 
                        return <tr key={item.id}>
                            <td>
                            <div class="cart-info">
                                <img src={"images/"+item.img} width="60px"/>
                                <div>
                                    <p>{item.title}</p>
                                    <small>Price: ₹{item.price} </small>
                                    <br/>
                                    <button onClick={dispatch(removeItem(item.id))}>Remove</button>
                                </div>
                            </div>
                            </td>
                            <td>
                                <button className="btn" onClick={dispatch(increment(item.id))}>+</button>
                                <input type="number" value={item.quantity}/>
                                <button className="btn"  onClick={dispatch(increment(item.id))}>-</button>
                            </td>
                            <td>₹{item.price * item.quantity} </td>
                        </tr>
                   })
                }
                </table>
            <div class="total-price">
                <table>
                    <tr>
                        <td>Subtotal</td>
                        <td>₹{state.totalAmount}</td>
                    </tr>
                    <tr>
                        <td>Tax</td>
                        <td>₹80.00</td>
                    </tr>
                    <tr>
                        <td>Total</td>
                        <td>₹{state.totalAmount + 80}</td>
                    </tr>
                </table>
            </div>
        </div>
    )
}
import React from "react";

export default function Featuredcategories() {
  return (
    <div className="categories">
      <div className="small-contain">
        <div className="row">
          <div className="col-3">
            <img src="images/category-1.jpg" alt="myimages" />
          </div>
          <div className="col-3">
            <img src="images/category-3.jpg" alt="myimages" />
          </div>
          <div className="col-3">
            <img src="images/category1.jpeg" alt="myimages" />
          </div>
          <div className="col-3">
            <img src="images/category-2.jpg" alt="myimages" />
          </div>
        </div>
      </div>
    </div>
  );
}

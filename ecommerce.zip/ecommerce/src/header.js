import React from "react";

export default function Header() {
  return (
    <div className="App">
      <div class="header">
        <div class="row">
          <div class="col-2">
            <h1>
              Smart Shooping Day
              <br />
              upto 50% OFF
            </h1>
            <ul>
              <li>
                <a href="">Beauty Combos</a>
              </li>
              <li>
                <a href="">Watches</a>
              </li>
              <li>
                <a href="">Men's Clothes</a>
              </li>
              <li>
                <a href="">Women's clothes</a>
              </li>
            </ul>
            <a href="" class="btn">
              Explore Now &#8594;
            </a>
          </div>
          <div class="col-2">
            <img src="images/home.jpg" alt=""/>
          </div>
        </div>
      </div>
    </div>
  );
}

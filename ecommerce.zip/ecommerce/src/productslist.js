export const productslist = [
    { 
        id:"1",
        title:"Men's Cotton T-Shirt",
        description:"best in the market only few left hurry up!!",
        price:"299",
        img:"product-3.jpg",
        category:"men",
        subcategory:"featured",
        quantity:1
    },
    { 
        id:"2",
        title:"Sport Shoes for men",
        description:"best in the market only few left hurry up!!",
        price:"500",
        img:"product-2.jpg",
        category:"men",
        subcategory:"featured",
        quantity:1
    },
    { 
        id:"3",
        title:"Cotton T-Shirt",
        description:"best in the market only few left hurry up!!",
        price:"400",
        img:"product-4.jpg",
        subcategory:"featured",
        category:"men",
        quantity:1
    },
    { 
        id:"4",
        title:"Style Sport Shoes for men",
        description:"best in the market only few left hurry up!!",
        price:"299",
        img:"product-5.jpg",
        category:"men",
        subcategory:"featured",
        quantity:1
    },
    { 
        id:"5",
        title:"LCD TV",
        description:"best in the market only few left hurry up!!",
        price:"13000",
        img:"arr_img1.jpg",
        category:"electronics",
        subcategory:"latest",
        quantity:1
    },
    { 
        id:"6",
        title:"Video Game",
        description:"best in the market only few left hurry up!!",
        price:"5000",
        img:"arr_img2.jpg",
        category:"electronics",
        subcategory:"latest",
        quantity:1
    },
    { 
        id:"7",
        title:"Sport Shoes",
        description:"best in the market only few left hurry up!!",
        price:"2000",
        img:"arr_img3.jpg",
        category:"men",
        subcategory:"latest",
        quantity:1
    },
    { 
        id:"8",
        title:"Smart Phones",   
        description:"best in the market only few left hurry up!!",
        price:"18000",
        img:"arr_img4.jpg",
        category:"electronics",
        subcategory:"latest",
        quantity:1
    },
    { 
        id:"9",
        title:"Style Sport Shoes for men",
        description:"best in the market only few left hurry up!!",
        price:"3000",
        img:"product-5.jpg",
        category:"men",
        subcategory:"latest",
        quantity:1
    },
    { 
        id:"10",
        title:"Men's Cotton T-shirt",
        description:"best in the market only few left hurry up!!",
        price:"600",
        category:"men",
        subcategory:"latest",
        img:"product-6.jpg",
        quantity:1
    },
    { 
        id:"11",
        title:"Smart watches",
        description:"best in the market only few left hurry up!!",
        price:"3000",
        category:"men",
        subcategory:"latest",
        img:"product-8.jpg",
        quantity:1
    },
    { 
        id:"12",
        title:"Sport Shoes for men",
        description:"best in the market only few left hurry up!!",
        price:"2000",
        category:"men",
        subcategory:"latest",
        img:"product-2.jpg",
        quantity:1
    },
    { 
        id:"13",
        title:"Blush Floral Mesh Top",
        description:"best in the market only few left hurry up!!",
        price:"550",
        img:"w1.jpg",
        category:"women",
        subcategory:"",
        quantity:1
    },
    { 
        id:"14",
        title:"Square Neck Top",
        description:"best in the market only few left hurry up!!",
        price:"500",
        category:"women",
        img:"w2.jpg",
        subcategory:"",
        quantity:1
    },
    { 
        id:"15",
        title:"Blush Floral Mesh Top",
        description:"best in the market only few left hurry up!!",
        price:"600",
        img:"w3.jpg",
        category:"women",
        subcategory:"",
        quantity:1
    },
    { 
        id:"16",
        title:"Square Neck Top",
        description:"best in the market only few left hurry up!!",
        price:"500",
        img:"w4.jpg",
        category:"women",
        subcategory:"",
        quantity:1
    },
    { 
        id:"17",
        title:"Mustard Work It Up Top",
        description:"best in the market only few left hurry up!!",
        price:"450",
        img:"w5.jpg",
        category:"women",
        subcategory:"",
        quantity:1
    },
    { 
        id:"18",
        title:"Blush Floral Mesh Top",
        description:"best in the market only few left hurry up!!",
        price:"550",
        img:"w6.jpg",
        category:"women",
        subcategory:"",
        quantity:1
    },
    { 
        id:"19",
        title:"Mustard Work It Up Top",
        description:"best in the market only few left hurry up!!",
        price:"650",
        img:"w7.jpg",
        category:"women",
        subcategory:"",
        quantity:1
    },
    { 
        id:"20",
        title:"Square Neck Top",
        description:"best in the market only few left hurry up!!",
        price:"500",
        img:"w8.jpg",
        category:"women",
        subcategory:"",
        quantity:1
    },
    { 
        id:"21",
        title:"Smart Band",
        description:"best in the market only few left hurry up!!",
        price:"3000",
        img:"exclusive.png",
        category:"band",
        subcategory:"",
        quantity:1
    },
    { 
        id:"22",
        title:"Smart Band",
        description:"best in the market only few left hurry up!!",
        price:"600",
        img:"k1.jpg",
        category:"kids",
        subcategory:"",
        quantity:1
    },
    { 
        id:"23",
        title:"Smart Band",
        description:"best in the market only few left hurry up!!",
        price:"500",
        img:"k2.jpg",
        category:"kids",
        subcategory:"",
        quantity:1
    },
    { 
        id:"24",
        title:"Smart Band",
        description:"best in the market only few left hurry up!!",
        price:"550",
        img:"k3.jpg",
        category:"kids",
        subcategory:"",
        quantity:1
    },
    { 
        id:"25",
        title:"Smart Band",
        description:"best in the market only few left hurry up!!",
        price:"600",
        img:"k4.jpg",
        category:"kids",
        subcategory:"",
        quantity:1
    }
]
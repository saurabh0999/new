import React from "react";

export default function Brands() {
  return (
    <div class="brands">
      <div class="small-contain">
        <div class="row">
          <div class="col-5">
            <img src={"images/logo-godrej.png"} alt="myimage" />
          </div>
          <div class="col-5">
            <img src={"images/logo-coca-cola.png"} alt="myimage" />
          </div>
          <div class="col-5">
            <img src={"images/logo-paypal.png"} alt="myimage" />
          </div>
          <div class="col-5">
            <img src={"images/logo-philips.png"} alt="myimage" />
          </div>
          <div class="col-5">
            <img src={"images/logo-oppo.png"} alt="myimage" />
          </div>
        </div>
      </div>
    </div>
  );
}

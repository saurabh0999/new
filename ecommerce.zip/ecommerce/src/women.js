import React from "react";
import { useSelector} from 'react-redux'
import { Link } from 'react-router-dom';
//import {productslist} from "./productslist"

export default function Women(){
    const productslist = useSelector((state) => state.products)
    return(
        <div>
            <h2 class="title">Women Clothes</h2>
            <div class="row">
                {productslist.map((item)=>{
                  return  (item.subcategory === "" && item.category === "women") ? 
                    ( <div class="col-4" key={item.id}>
                        <Link to={"/productdetails/"+item.id}>
                            <img src={"images/"+item.img} />
                            <h4>{item.title}</h4>
                            <div class="rating">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="far fa-star"></i>
                                <i class="far fa-star"></i>
                            </div>
                            <p>Price: ₹{item.price}</p>
                        </Link>
                    </div> ) : ''
                    })
                }   
           </div>   
        </div>
    )
}
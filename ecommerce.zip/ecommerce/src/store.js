import { createStore } from 'redux'
import productReducer from './productReducer'

let store = createStore(productReducer,  window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__())

store.subscribe(() => {
    console.log('current state', store.getState());
});

export default store;
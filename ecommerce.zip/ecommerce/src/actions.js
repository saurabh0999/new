 // add item to cart
 export const addItem = (item) => {
    return {
      type: "ADD_ITEM",
      payload: item,
    };
  };

// remove item from cart
  export const removeItem = (id) => {
    return {
      type: "REMOVE_ITEM",
      payload: id,
    };
  };

  // clear the cart
  export const clearCart = () => {
    return { type: "CLEAR_CART" };
  };

  // increment the item
  export const increment = (id) => {
    return {
      type: "INCREMENT",
      payload: id,
    };
  };
  
  // decrement the item
  export const decrement = (id) => {
    return {
      type: "DECREMENT",
      payload: id,
    };
  };
  
  export const gettotal = () => {
    return { type: "GET_TOTAL" }
  }
import React from "react";
import {Link} from 'react-router-dom';

export default function Offer() {
  return (
    <div className="offer">
      <div className="small-contain">
        <div className="row">
          <div className="col-2">
            <img src="images/exclusive.png" className="offer-img" />
          </div>
          <div className="col-2">
            <p> Exclusively Available On E Shopify</p>
            <h1> Smart band</h1>
            <small>
              Ring enables you to make and receive calls directly from your
              watch via the built-in speaker and microphone. This smartwatch
              features a dial pad, option to access recent calls.
            </small>
            <Link to="/productdetails" className="btn">
              Buy Now &#8594;
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

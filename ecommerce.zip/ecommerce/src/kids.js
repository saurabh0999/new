import React  from "react";
import { useSelector } from 'react-redux'
import { Link } from 'react-router-dom';
//import {productslist} from "./productslist"

export default function Kids() {
    const productslist = useSelector((state) => state.products)
    return(
        <div>
            <h2 className="title">Kids Clothes</h2>
            <div className="row">
            {productslist.map((item)=>{
                return  (item.category === "kids") ? 
                    (<div className="col-4"  key={item.id}>
                        <Link to={"/productdetails/"+item.id}>
                            <img src={"images/"+item.img}/>
                            <h4>{item.title}</h4>
                            <div className="rating">
                                <i className="fas fa-star"></i>
                                <i className="fas fa-star"></i>
                                <i className="fas fa-star"></i>
                                <i className="far fa-star"></i>
                                <i className="far fa-star"></i>
                            </div>
                            <p>Price: ₹{item.price}</p>
                        </Link>
                    </div> ) : ''
                })
            }
            </div>
        </div>
    )
}
import React, {useState}  from "react";
import { useParams } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { addItem } from "./actions";

export default function Productdetails() {
    const [quantity, setQantity] = useState(1);
    const productslist = useSelector((state) => state.products)
    const dispatch = useDispatch();
    let { id } = useParams();
    console.log("id = "+id);
    return(
        <div>
            <div className="small-contain single-product">
            {productslist.map((item)=>{
                const myitem = {id:item.id, title:item.title, img:item.img, description:item.description, price:item.price, quantity:quantity}
                return  item.id === id ? 
                    (<div className="row" key={item.id}>
                        <div className="col-2">
                            <img src={"../images/"+item.img} width="100%" id="ProductImg"/>
                        </div>
                        <div className="col-2" >
                            <h2>{item.title}</h2>
                            <h4>Price:	₹{item.price}</h4>
                            <select>
                                <option>Select Size</option>
                                <option>XXL</option>
                                <option>XL</option>
                                <option>L</option>
                                <option>M</option>
                            </select>
                            <input type="number" value={quantity} onChange={(e) => setQantity(e.target.value)}/>
                            <button className="btn" onClick={()=>dispatch(addItem(myitem))}>Add to cart</button>
                            <h3>Detail Featured <i className="fa fa-indent"></i></h3>
                            <p>{item.description}<br/>Return Period: 15 Days</p>
                        </div>
                    </div> ) :''
                })
            }           
         </div>
            
        </div>
    )
}
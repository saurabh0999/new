import React, {useEffect} from 'react';
import {useSelector, useDispatch} from 'react-redux'
import './style.css';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import Home from './home';
import Nav from "./nav";
import Account from "./Account";
import Kids from "./kids";
import Women from "./women";
import Products from "./products";
import Productdetails from "./productdetails";
import Shoppingcart from "./shoppingcart";
import Footer from "./footer";
import { gettotal } from './actions';

function Main() {
   const cart = useSelector((state) => state.cart)
   const dispatch = useDispatch();
  // we will use the useEffect to update the data
  // useEffect(() => {
  //   dispatch(gettotal());
  //   // console.log("Awesome");
  // }, [cart]);

  return (
    <div className="App">
        <BrowserRouter>
          <Nav />
          <Switch>
            <Route exact path="/" component={Account}/>
            <Route path="/home" component={Home}/>  
            <Route path="/kids" component={Kids}/>
            <Route path="/women" component={Women}/>
            <Route path="/products" component={Products}/>           
            <Route path="/productdetails/:id" component={Productdetails}/>
            <Route path="/shoppingcart" component={Shoppingcart}/>
          </Switch>
          <Footer />
        </BrowserRouter>  
    </div>
  );
}

export default Main;

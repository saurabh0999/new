import React  from "react";
import { useSelector } from 'react-redux'
import { Link } from 'react-router-dom';

export default function Products() {
    const productslist = useSelector((state) => state.products)
    return(
        <div className="small-contain">
            <div className="row row-2">
            <h2>All Products</h2>
            <select>
                <option>Short by Price</option>
                <option>Short by Size</option>
                <option>Short by Popularity</option>
            </select>
            </div>
            <div className="row">
                {
                  productslist.map((item)=>{
                    return <div className="col-4" key={item.id}>
                              <Link to={"/productdetails/"+item.id}>
                                <img src={"images/"+item.img} alt="myimage"/>
                                <h4>{item.title}</h4>
                                <div className="rating">
                                    <i className="fas fa-star"></i>
                                    <i className="fas fa-star"></i>
                                    <i className="fas fa-star"></i>
                                    <i className="far fa-star"></i>
                                    <i className="far fa-star"></i>
                                </div>
                                <p>Price: ₹{item.price}</p>
                            </Link>
                        </div>
                       
                    })
                }        
            </div>
            
         
            <div className="page-btn">
                <span>1</span>
                <span>2</span>
                <span>3</span>
                <span>4</span>
                <span>&#8594</span>
            </div>
        </div>
    )
}